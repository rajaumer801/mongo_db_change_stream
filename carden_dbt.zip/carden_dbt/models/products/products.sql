{{
    config(
        materialized='incremental',
        sql_where='TRUE',
        unique_key='id'
    )
}}

with oplog_events as (
    select
        documentKey as id,
        _id AS last_event_id,
        clusterTime as updated_at,
	JSON_EXTRACT(fullDocument,'$.item') AS item,
        JSON_EXTRACT(fullDocument,'$.qty') AS qty
    from
        `mongo_bq.change_log`
    where
        collection = 'products'
    {% if adapter.already_exists(this.schema, this.table) and not flags.FULL_REFRESH %}
        and clusterTime > (select max(updated_at) from `final.products`)
    {% endif %}
),

event_sequences as (
    select
        *
        , row_number() over (partition by id order by updated_at desc) as sequence
    from oplog_events
)

select distinct
    * except(sequence)
from event_sequences as s
where sequence = 1
